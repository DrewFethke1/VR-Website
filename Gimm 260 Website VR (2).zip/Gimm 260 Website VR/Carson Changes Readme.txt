1.The first change that Carson gave me was to change the color othe the line on the first graph from blue to black to increase visibility which was very easy

2.The second change was to add a css animation which Carson told me that I should make a pure gradient text animation so I made a css pure gradiant animaton for the text on every title block

3.Origainaly the webpage only had a navbar on the the homepage which is why the homepage is empty amd you would use the back button to go back, Carson told me it would be better to have a Navbar on every webpage which i did but it required me to pretty much reformat every webpage so it still looked good.